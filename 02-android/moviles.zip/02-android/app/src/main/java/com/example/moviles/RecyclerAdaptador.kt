package com.example.moviles

class RecyclerAdaptador {
}